import EstudianteModel from '../models/clienteModel.js';

export const createEstudiante = async (req, res) => {
    try {
        
        const { nombreEst, apellidoPatEst, apellidoMatEst, domicilioEst, ciudadEst, telefonoEst, correoEst, controlEst } = req.body;

        const estudiante = await EstudianteModel.create({
            nombreEst,
            apellidoPatEst,
            apellidoMatEst,
            domicilioEst,
            ciudadEst,
            telefonoEst,
            correoEst,
            controlEst
        });

        // Responder con el estudiante creado
        res.status(201).json(estudiante);
    } catch (error) {
        // Capturar y responder con el error
        console.error("Error al crear el estudiante:", error);  // Agregar un log para depurar
        res.status(400).json({ error: error.message });
    }
};

// Obtener todos los estudiantes
export const getEstudiantes = async (req, res) => {
    try {
        const estudiantes = await EstudianteModel.findAll();
        res.json(estudiantes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Obtener un estudiante por su ID
export const getEstudianteById = async (req, res) => {
    try {
        const estudiante = await EstudianteModel.findByPk(req.params.id);
        if (!estudiante) {
            return res.status(404).json({ error: 'Estudiante no encontrado' });
        }
        res.json(estudiante);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Actualizar un estudiante
export const updateEstudiante = async (req, res) => {
    try {
        const [updated] = await EstudianteModel.update(req.body, {
            where: { id: req.params.id },
        });

        if (updated) {
            const updatedEstudiante = await EstudianteModel.findByPk(req.params.id);
            return res.json(updatedEstudiante); // Responder con los datos actualizados
        }

        res.status(404).json({ error: 'Estudiante no encontrado' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Eliminar un estudiante
export const deleteEstudiante = async (req, res) => {
    try {
        const deleted = await EstudianteModel.destroy({
            where: { id: req.params.id },
        });

        if (deleted) {
            return res.status(204).send(); // 204: Sin contenido
        }

        res.status(404).json({ error: 'Estudiante no encontrado' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
