import express from 'express';
import {
    createEstudiante,
    getEstudiantes,
    getEstudianteById,
    updateEstudiante,
    deleteEstudiante,
} from '../controllers/clienteController.js';

const router = express.Router();

// Ruta para crear un estudiante
router.post('/', createEstudiante);

// Ruta para obtener todos los estudiantes
router.get('/', getEstudiantes);

// Ruta para obtener un estudiante por su ID
router.get('/:id', getEstudianteById);

// Ruta para actualizar un estudiante
router.put('/:id', updateEstudiante);

// Ruta para eliminar un estudiante
router.delete('/:id', deleteEstudiante);

export default router;
